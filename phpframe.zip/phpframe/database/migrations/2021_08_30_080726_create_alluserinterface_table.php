<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAlluserinterfaceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('alluserinterfaces', function (Blueprint $table) {
            $table->id();
            $table->string('buddyname');
            $table->string('buddycontact');
            $table->string('buddyemail')->unique();
            $table->string('buddyreference');
            $table->string('buddyvillage');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('alluserinterfaces');
    }
}
