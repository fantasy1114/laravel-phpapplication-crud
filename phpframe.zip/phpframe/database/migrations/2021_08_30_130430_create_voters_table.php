<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVotersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('voters', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('wifehusname');
            $table->string('father');
            $table->string('mother');
            $table->string('housenum');
            $table->string('age');
            $table->string('gender');
            $table->string('sectionname');
            $table->string('village');
            $table->string('filename');
            $table->string('status');
            $table->string('phone');
            $table->string('buddyemail')->unique();
            $table->string('buddycontact');

            $table->boolean('jobs')->default(0);
            $table->boolean('food')->default(0);
            $table->boolean('finance')->default(0);
            $table->boolean('family')->default(0);
            $table->boolean('business')->default(0);
            $table->boolean('socialevils')->default(0);
            $table->boolean('security')->default(0);
            $table->boolean('abuse')->default(0);
            $table->boolean('water')->default(0); 
            $table->boolean('electricity')->default(0);
            $table->boolean('suggestions')->default(0);
            $table->boolean('youth')->default(0);
            $table->boolean('disability')->default(0);
            $table->boolean('elderly')->default(0);
            $table->boolean('arts')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('voters');
    }
}
