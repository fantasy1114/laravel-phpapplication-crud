<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alluserinterface;
use App\Models\Logs;
use Illuminate\Support\Facades\DB;

class AlluserinterfaceController extends Controller
{
  // User List Page
  public function index()
  {
    $alluserinterfaces = DB::table('alluserinterfaces')->get();
    return view('/interface', ['alluserinterfaces' => $alluserinterfaces]);
  }

  public function interfacecreate()
  {
    $alluserinterfaces = DB::table('alluserinterfaces')->get();
    $logs = DB::table('logs')->get();
    $interfacechecking = 0;
    foreach ($alluserinterfaces as $alluserinterface) {
      $buddyemail = $alluserinterface->buddyemail;
      if (request('buddy_email') == $buddyemail){
        $interfacechecking = 1;
      }
    }
    if($interfacechecking == 0){
      $Alluserinterface = new Alluserinterface;
      $Alluserinterface->buddyname = request('buddy_name');
      $Alluserinterface->buddycontact = request('buddy_contact');
      $Alluserinterface->buddyemail = request('buddy_email');
      $Alluserinterface->buddyreference = request('buddy_reference');
      $Alluserinterface->buddyvillage = request('buddy_village');
      $Alluserinterface->save();
      $Logs = new Logs;
      $Logs->username = request('usernamesave');
      $Logs->tablename = 'Buddy';
      $Logs->crudevent = 'add';
      $Logs->description = request('buddy_name');
      $Logs->save();
    
      return response()->json(['success'=>true]);
    }
    return response()->json(['success'=>false]);
  }
  public function interfacedelete($id, $name)
  {
    $description = DB::table('alluserinterfaces')->where('id', $id)->value('buddyname');
    $Logs = new Logs;
    $Logs->username = $name;
    $Logs->tablename = 'Buddy';
    $Logs->crudevent = 'delete';
    $Logs->description = $description;
    $Logs->save();
    DB::table('alluserinterfaces')->where('id', $id)->delete();
    // $userlists = DB::table('users')->get();
    // return view('/userlist', ['userlists' => $userlists]);
    return redirect('/interface');
  }
  public function interfaceupdate(Request $request, $id)
  {
    // var_dump($id);
    // var_dump($request);
    $validatedData = $request->validate([
        'buddyname' => 'required',
        'buddycontact' => 'required',
        'buddyemail' => 'required',
        'buddyreference' => 'required',
        'buddyvillage' => 'required',
    ]);
    

    DB::table('alluserinterfaces')->where('id', $id)->update([
        'buddyname' => $validatedData['buddyname'],
        'buddycontact' => $validatedData['buddycontact'],
        'buddyemail' => $validatedData['buddyemail'],
        'buddyreference' => $validatedData['buddyreference'],
        'buddyvillage' => $validatedData['buddyvillage']
    ]);

    $Logs = new Logs;
    $Logs->username = request('usernamesave');
    $Logs->tablename = 'Buddy';
    $Logs->crudevent = 'update';
    $Logs->description = request('buddyname');
    $Logs->save();

    return response()->json(['success'=>true]);
  }
}
