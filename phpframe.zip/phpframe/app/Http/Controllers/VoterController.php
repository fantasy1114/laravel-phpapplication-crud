<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Voter;
use App\Models\Alluserinterface;
use Illuminate\Support\Facades\DB;
use App\Models\Logs;

class VoterController extends Controller
{
  // User List Page
  public function index()
  {
    $voters = DB::table('voters')->get();
    $alluserinterfaces = DB::table('alluserinterfaces')->get();
    return view('/voter', ['voters' => $voters], ['alluserinterfaces' => $alluserinterfaces]);
  }

  public function votercreate()
  {
    $voters = DB::table('voters')->get();
    $logs = DB::table('logs')->get();
    $voterschecking = 0;
    foreach ($voters as $voter) {
      $buddyemail = $voter->buddyemail;
      if (request('buddy_email') == $buddyemail){
        $voterschecking = 1;
      }
    }
    if($voterschecking == 0){
      $Voter = new Voter;
      $Voter->name = request('voter_name');
      $Voter->wifehusname = request('wifehusname');
      $Voter->father = request('father');
      $Voter->mother = request('mother');
      $Voter->housenum = request('housenum');
      $Voter->age = request('age');
      $Voter->gender = request('gender');
      $Voter->sectionname = request('sectionname');
      $Voter->village = request('village');
      $Voter->filename = request('filename');
      $Voter->status = request('status');
      $Voter->phone = request('phone');
      $Voter->buddyemail = request('buddyemail');
      $Voter->buddycontact = request('buddycontact');
      $Voter->save();

      $Logs = new Logs;
      $Logs->username = request('usernamesave');
      $Logs->tablename = 'Voter';
      $Logs->crudevent = 'add';
      $Logs->description = request('voter_name');
      $Logs->save();
    
      return response()->json(['success'=>true]);
    }
    return response()->json(['success'=>false]);
  }
  public function voterdelete($id, $name)
  {
    $description = DB::table('voters')->where('id', $id)->value('name');
    // var_dump($description);
    $Logs = new Logs;
    $Logs->username = $name;
    $Logs->tablename = 'Voter';
    $Logs->crudevent = 'delete';
    $Logs->description = $description;
    $Logs->save();

    DB::table('voters')->where('id', $id)->delete();
    return redirect('/voter');
  }
  public function voterupdate(Request $request, $id)
  {
    // var_dump($id);
    // // var_dump($request);
    $validatedData = $request->validate([
        'name' => 'required',
        'wifehusname' => 'required',
        'father' => 'required',
        'mother' => 'required',
        'housenum' => 'required',
        'age' => 'required',
        'gender' => 'required',
        'sectionname' => 'required',
        'village' => 'required',
        'filename' => 'required',
        'status' => 'required',
        'phone' => 'required',
        'buddyemail' => 'required',
        'buddycontact' => 'required'
    ]);
 
    DB::table('voters')->where('id', $id)->update([
        'name' => $validatedData['name'],
        'wifehusname' => $validatedData['wifehusname'],
        'father' => $validatedData['father'],
        'mother' => $validatedData['mother'],
        'housenum' => $validatedData['housenum'],
        'age' => $validatedData['age'],
        'gender' => $validatedData['gender'],
        'sectionname' => $validatedData['sectionname'],
        'village' => $validatedData['village'],
        'filename' => $validatedData['filename'],
        'status' => $validatedData['status'],
        'phone' => $validatedData['phone'],
        'buddyemail' => $validatedData['buddyemail'],
        'buddycontact' => $validatedData['buddycontact'],
    ]);
    $Logs = new Logs;
    $Logs->username = request('usernamesave');
    $Logs->tablename = 'Voter';
    $Logs->crudevent = 'update';
    $Logs->description = request('name');
    $Logs->save();
    
    return response()->json(['success'=>true]);
  }
}
