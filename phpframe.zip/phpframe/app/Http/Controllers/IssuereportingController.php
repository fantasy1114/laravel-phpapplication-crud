<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Voter;
use App\Models\Alluserinterface;
use Illuminate\Support\Facades\DB;
use App\Models\Logs;

class IssuereportingController extends Controller
{
  // User List Page
  public function index()
  {
    $voters = DB::table('voters')->get();
    return view('/issuereporting', ['voters' => $voters]);
  }

  public function issuereportingupdate(Request $request, $id)
  {
    var_dump($id);
    // var_dump($request);
    $validatedData = $request->validate([
        'jobs' => 'required',
        'food' => 'required',
        'finance' => 'required',
        'family' => 'required',
        'business' => 'required',
        'socialevils' => 'required',
        'security' => 'required',
        'abuse' => 'required',
        'water' => 'required',
        'electricity' => 'required',
        'suggestions' => 'required',
        'youth' => 'required',
        'disability' => 'required',
        'elderly' => 'required',
        'arts' => 'required'
    ]);
  
    DB::table('voters')->where('id', $id)->update([
        'jobs' => $validatedData['jobs'],
        'food' => $validatedData['food'],
        'finance' => $validatedData['finance'],
        'family' => $validatedData['family'],
        'business' => $validatedData['business'],
        'socialevils' => $validatedData['socialevils'],
        'security' => $validatedData['security'],
        'abuse' => $validatedData['abuse'],
        'water' => $validatedData['water'],
        'electricity' => $validatedData['electricity'],
        'suggestions' => $validatedData['suggestions'],
        'youth' => $validatedData['youth'],
        'disability' => $validatedData['disability'],
        'elderly' => $validatedData['elderly'],
        'arts' => $validatedData['arts']
    ]);
    $description = DB::table('voters')->where('id', $id)->value('name');
    $Logs = new Logs;
    $Logs->username = request('usernamesave');
    $Logs->tablename = 'Issue Reporting';
    $Logs->crudevent = 'update';
    $Logs->description = $description;
    $Logs->save();
    
    return response()->json(['success'=>true]);
  }
}
