<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Hash;
use Session;
use App\Models\Logs;

class UserlistController extends Controller
{
  // User List Page
  public function userlist()
  {
    $userlists = DB::table('users')->get();
    return view('/userlist', ['userlists' => $userlists]);
  }
  public function usercreate()
  {
    $userlists = DB::table('users')->get();
    // print_r($userlists);
    $userchecking = 0;
    foreach ($userlists as $userlist) {
      $email = $userlist->email;
      if (request('user_email') == $email){
        $userchecking = 1;
      }
      // echo $email;
      // echo '<br>';
    }
    if($userchecking == 0){
      $User = new User;
      $User->name = request('user_fullname');
      $User->email = request('user_email');
      $User->role = request('user_role');
      $User->password = Hash::make(request('user_password'));
      $User->save();
      $Logs = new Logs;
      $Logs->username = request('usernamesave');
      $Logs->tablename = 'Userlist';
      $Logs->crudevent = 'add';
      $Logs->description = request('user_fullname');
      $Logs->save();
      return response()->json(['success'=>true]);
    }
    
    return response()->json(['success'=>false]);
  }
  public function userdelete($id, $name)
  {
    $description = DB::table('users')->where('id', $id)->value('name');
    // var_dump($description);
    $Logs = new Logs;
    $Logs->username = $name;
    $Logs->tablename = 'userlist';
    $Logs->crudevent = 'delete';
    $Logs->description = $description;
    $Logs->save();
    DB::table('users')->where('id', $id)->delete();

    return redirect('/userlist');
  }
  public function userupdate(Request $request, $id)
  {
    $Logs = new Logs;
    $Logs->username = request('usernamesave');
    $Logs->tablename = 'userlist';
    $Logs->crudevent = 'update';
    $Logs->description = request('name');
    $Logs->save();

    $validatedData = $request->validate([
        'name' => 'required',
        'email' => 'required',
        'role' => 'required',
    ]);
    
    DB::table('users')->where('id', $id)->update([
        'name' => $validatedData['name'],
        'email' => $validatedData['email'],
        'role' => $validatedData['role'],
    ]);
    
    return response()->json(['success'=>true]);
  }
}
