<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->
@include('layouts/header')
<!-- END: Head-->
<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static  " data-open="click"
    data-menu="vertical-menu-modern" data-col="">

    <!-- BEGIN: navbar-->
    @include('layouts/navbar')
    <!-- END navbar -->

    <!-- BEGIN LAYOUT -->
    @include('layouts/layout')
    <!-- END LAYOUT -->
    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <!-- users list start -->
                <section class="app-user-list">
                    <!-- users filter start -->
                    <div class="card">
                        <h5 class="card-header">Search</h5>
                        <div class="d-flex justify-content-between align-items-center mx-50 row pt-0 pb-2">
                            <div class="col-md-4 user_plan"></div>
                            <div class="col-md-4 user_role"></div>
                            <div class="col-md-4 user_status"></div>
                        </div>
                    </div>
                    <!-- users filter end -->
                    <!-- list section start -->
                    <div class="card">
                        <div class="card-datatable table-responsive pt-0">
                            <table class="user-list-table table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Husbands/Wife Name</th>
                                        <th>Fathers Name</th>
                                        <th>Mothers Name</th>
                                        <th>House Number</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Section No and Name</th>
                                        <th>Village</th>
                                        <th>File Name</th>
                                        <th>Status</th>
                                        <th>Phone</th>
                                        <th>email</th>
                                        <th>Buddy Contact</th>
                                        <th>Update</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $index = 1; ?>
                                    @foreach ($voters as $voter)
                                    <tr>
                                        <td style="cursor:pointer;"><div class="rounded-circle justify-content-center text-center" style="width:34px;height:34px;background-color:#7367f0;color:white;line-height: 2.3;font-weight: 600;"><?php  echo $index++ ?></div></td>
                                        <td>{{$voter -> name}}</td>
                                        <td>{{$voter -> wifehusname}}</td>
                                        <td>{{$voter -> father}}</td>
                                        <td>{{$voter -> mother}}</td>
                                        <td>{{$voter -> housenum}}</td>
                                        <td>{{$voter -> age}}</td>
                                        <td>{{$voter -> gender}}</td>
                                        <td>{{$voter -> sectionname}}</td>
                                        <td>{{$voter -> village}}</td>
                                        <td>{{$voter -> filename}}</td>
                                        <td>{{$voter -> status}}</td>
                                        <td>{{$voter -> phone}}</td>
                                        <td>{{$voter -> buddyemail}}</td>
                                        <td>{{$voter -> buddycontact}}</td>
                                        <td>
                                            <button type="button" class="btn btn-icon btn-icon rounded-circle btn-warning update_issue" data-id="{{$voter -> id}}" data-name="{{$voter -> name}}" data-jobs="{{$voter -> jobs}}" data-food="{{$voter -> food}}" data-finance="{{$voter -> finance}}" data-family="{{$voter -> family}}" data-business="{{$voter -> business}}" data-socialevils="{{$voter -> socialevils}}" data-security="{{$voter -> security}}" data-abuse="{{$voter -> abuse}}" data-water="{{$voter -> water}}" data-electricity="{{$voter -> electricity}}" data-suggestions="{{$voter -> suggestions}}" data-youth="{{$voter -> youth}}" data-disability="{{$voter -> disability}}" data-elderly="{{$voter -> elderly}}" data-arts="{{$voter -> arts}}" >
                                                <i data-feather="inbox"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade text-left update_default_view" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel1"><span class="modal_data_title"></span></h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="issue_update_modal_data w-100 align-middle">
                                            <tr>
                                                <td>Jobs:</td>
                                                <td><input type="checkbox" id="updatejobs" class="updatejobs"></td>
                                                <td>Food:</td>
                                                <td><input type="checkbox" id="updatefood" class="updatefood"></td>
                                            </tr>

                                            <tr>
                                                <td>Finance:</td>
                                                <td><input type="checkbox" id="updatefinance" class="updatefinance"></td>
                                                <td>Family:</td>
                                                <td><input type="checkbox" id="updatefamily" class="updatefamily"></td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Business:</td>
                                                <td><input type="checkbox" id="updatebusiness" class="updatebusiness"></td>
                                                <td>Socialevils:</td>
                                                <td><input type="checkbox" id="updatesocialevils" class="updatesocialevils"></td>
                                            </tr>
                                            <tr>
                                                <td>Security:</td>
                                                <td><input type="checkbox" id="updatesecurity" class="updatesecurity"></td>
                                                <td>Abuse:</td>
                                                <td><input type="checkbox" id="updateabuse" class="updateabuse"></td>
                                            </tr>
                                           
                                            <tr>
                                                <td>Water:</td>
                                                <td><input type="checkbox" id="updatewater" class="updatewater"></td>
                                                <td>Electricity:</td>
                                                <td><input type="checkbox" id="updateelectricity" class="updateelectricity"></td>
                                            </tr>
                                           
                                            <tr>
                                                <td>Suggestions:</td>
                                                <td><input type="checkbox" id="updatesuggestions" class="updatesuggestions"></td>
                                                <td>Youth:</td>
                                                <td><input type="checkbox" id="updateyouth" class="updateyouth"></td>
                                            </tr>
                                          
                                            <tr>
                                                <td>Disability:</td>
                                                <td><input type="checkbox" id="updatedisability" class="updatedisability"></td>
                                                <td>Elderly:</td>
                                                <td><input type="checkbox" id="updateelderly" class="updateelderly"></td>
                                            </tr>
                                           
                                            <tr>
                                                <td>Arts:</td>
                                                <td><input type="checkbox" id="updatearts" class="updatearts"></td>
                                            </tr>
                                            <input type="text" value="{{Auth::user()->name}}" id="Uusernamesave" name="Uusernamesave" hidden>
                                        </table>
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary update_data_save {{Auth::user()->role}}" data-dismiss="modal">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        <!-- Basic trigger modal end -->
                    </div>
                    <!-- list section end -->
                </section>
                <!-- users list ends -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    @include('layouts/footer')
    <!-- END: Footer-->

    <!-- BEGIN: Page JS-->
    <script src="../../../app-assets/js/scripts/pages/app-issuereporting-list.js"></script>
    <!-- END: Page JS-->

    <script>
    $(function() {
        $(".update_issue").on("click", function() {
            var $id = $(this).data('id');
            var $userid = 'issuereportingupdate/' + ($(this).data('id'));
            $('.modal_data_title').html($(this).data('name'));

            // console.log($(this).data('jobs'));
            if($(this).data('jobs') == 1){
                $("#updatejobs").prop('checked', true);
            }
            if($(this).data('food') == 1){
                $("#updatefood").prop('checked', true);
            }
            if($(this).data('finance') == 1){
                $("#updatefinance").prop('checked', true);
            }
            if($(this).data('family') == 1){
                $("#updatefamily").prop('checked', true);
            }
            if($(this).data('business') == 1){
                $("#updatebusiness").prop('checked', true);
            }
            if($(this).data('socialevils') == 1){
                $("#updatesocialevils").prop('checked', true);
            }
            if($(this).data('security') == 1){
                $("#updatesecurity").prop('checked', true);
            }
            if($(this).data('abuse') == 1){
                $("#updateabuse").prop('checked', true);
            }
            if($(this).data('water') == 1){
                $("#updatewater").prop('checked', true);
            }
            if($(this).data('electricity') == 1){
                $("#updateelectricity").prop('checked', true);
            }
            if($(this).data('suggestions') == 1){
                $("#updatesuggestions").prop('checked', true);
            }
            if($(this).data('youth') == 1){
                $("#updateyouth").prop('checked', true);
            }
            if($(this).data('disability') == 1){
                $("#updatedisability").prop('checked', true);
            }
            if($(this).data('elderly') == 1){
                $("#updateelderly").prop('checked', true);
            }
            if($(this).data('arts') == 1){
                $("#updatearts").prop('checked', true);
            }

            $(".update_default_view").modal('show');

            $('.update_data_save').on("click", function() {
                console.log($userid);
                $updatejobs = 0;
                $updatefood = 0;
                $updatefinance = 0;
                $updatefamily = 0;
                $updatebusiness = 0; 
                $updatesocialevils = 0; 
                $updatesecurity = 0; 
                $updateabuse = 0; 
                $updatewater = 0; 
                $updateelectricity = 0; 
                $updatesuggestions = 0; 
                $updateyouth = 0; 
                $updateelderly = 0; 
                $updatearts = 0; 
                $updatedisability = 0;
                
                if ($('input.updatejobs').is(':checked')){
                    $updatejobs = 1
                }
                if ($('input.updatefood').is(':checked')){
                    $updatefood = 1
                }
                if ($('input.updatefinance').is(':checked')){
                    $updatefinance = 1
                }
                if ($('input.updatefamily').is(':checked')){
                    $updatefamily = 1
                }
                if ($('input.updatebusiness').is(':checked')){
                    $updatebusiness = 1
                }
                if ($('input.updatesocialevils').is(':checked')){
                    $updatesocialevils = 1
                }
                if ($('input.updatesecurity').is(':checked')){
                    $updatesecurity = 1
                }
                if ($('input.updateabuse').is(':checked')){
                    $updateabuse = 1
                }
                if ($('input.updatewater').is(':checked')){
                    $updatewater = 1
                }
                if ($('input.updateelectricity').is(':checked')){
                    $updateelectricity = 1
                }
                if ($('input.updatesuggestions').is(':checked')){
                    $updatesuggestions = 1
                }
                if ($('input.updateyouth').is(':checked')){
                    $updateyouth = 1
                }
                if ($('input.updatedisability').is(':checked')){
                    $updatedisability = 1
                }
                if ($('input.updateelderly').is(':checked')){
                    $updateelderly = 1
                }
                if ($('input.updatearts').is(':checked')){
                    $updatearts = 1
                }
                console.log($updatearts, $updateelderly, $updateyouth, $updatedisability, $updateelectricity);
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'post',
                    url: $userid,
                    data: {
                        id: $id,
                        jobs: $updatejobs,
                        food: $updatefood,
                        finance: $updatefinance,
                        family: $updatefamily,
                        business: $updatebusiness,
                        socialevils: $updatesocialevils,
                        security: $updatesecurity,
                        abuse: $updateabuse,
                        water: $updatewater,
                        electricity: $updateelectricity,
                        suggestions: $updatesuggestions,
                        youth: $updateyouth,
                        disability: $updatedisability,
                        elderly: $updateelderly,
                        arts: $updatearts,
                        usernamesave: $('#Uusernamesave').val()
                    },
                    // success: function(data) {
                    //     console.log(data);
                    //     if(data['success']){
                    //         window.location.reload();
                    //     }
                    // }
                });
                window.location.reload();
            });
        });

    })
    $(window).on('load', function() {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    });
    </script>
</body>
<!-- END: Body-->

</html>