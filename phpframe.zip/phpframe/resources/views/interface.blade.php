<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->
@include('layouts/header')
<!-- END: Head-->
<!-- BEGIN: Body-->
<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="">

    <!-- BEGIN: navbar-->
    @include('layouts/navbar')
    <!-- END navbar -->

    <!-- BEGIN LAYOUT -->
    @include('layouts/layout')
    <!-- END LAYOUT -->

    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <!-- users list start -->
                <section class="app-user-list">
              
                    <!-- list section start -->
                    <div class="card">
                        <div class="card-datatable table-responsive pt-0">
                            <table class="user-list-table table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Buddy</th>
                                        <th>Buddy Name</th>
                                        <th>Buddy Contact</th>
                                        <th>buddy Email</th>
                                        <th>Buddy Reference</th>
                                        <th>Buddy Village</th>
                                        <th class="{{Auth::user()->role}}">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($alluserinterfaces as $alluserinterface)
                                        <tr>
                                            <td>{{$alluserinterface -> buddyname}}</td>
                                            <td>{{$alluserinterface -> buddyname}}</td>
                                            <td>{{$alluserinterface -> buddycontact}}</td>
                                            <td>{{$alluserinterface -> buddyemail}}</td>
                                            <td>{{$alluserinterface -> buddyreference}}</td>
                                            <td>{{$alluserinterface -> buddyvillage}}</td>
                                            <td class="{{Auth::user()->role}}">
                                                <div class="dropdown">
                                                    <button type="button" class="btn btn-sm dropdown-toggle hide-arrow" data-toggle="dropdown">
                                                        <!-- <i data-feather="more-vertical"></i> -->
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <button class="dropdown-item userupdate_new" data-id="{{$alluserinterface -> id}}" data-buddyname="{{$alluserinterface -> buddyname}}" data-buddycontact="{{$alluserinterface -> buddycontact}}" data-buddyemail="{{$alluserinterface -> buddyemail}}" data-buddyreference="{{$alluserinterface -> buddyreference}}" data-buddyvillage="{{$alluserinterface -> buddyvillage}}">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 mr-50"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>
                                                            <span>Edit</span>
                                                        </button>
                                                        <a class="dropdown-item" href="interfacedelete/{{$alluserinterface->id}}/{{Auth::user()->name}}" >
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash mr-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                                            <span>Delete</span>
                                                        </a>
                                                        
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- Modal to add new user starts-->
                        <div class="modal modal-slide-in new-user-modal fade" id="modals-slide-in">
                            <div class="modal-dialog">
                                <form class="add-new-user modal-content pt-0" >
                                    {{csrf_field()}}
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                                    <div class="modal-header mb-1">
                                        <h5 class="modal-title" id="exampleModalLabel">New Buddy</h5>
                                    </div>
                                    <div class="modal-body flex-grow-1">
                                        <div class="form-group">
                                            <label class="form-label" for="buddy_name">Buddy Name</label>
                                            <input type="text" class="form-control dt-full-name" id="buddy_name" placeholder="John Doe" name="buddy_name" aria-label="John Doe" aria-describedby="buddy_name2" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="buddy_contact">Buddy Contact</label>
                                            <input type="text" class="form-control dt-Contact" id="buddy_contact" placeholder="John Doe" name="buddy_contact" aria-label="John Doe" aria-describedby="buddy_contact2" />
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="buddy_email">Buddy Email</label>
                                            <input type="email" id="buddy_email" class="form-control dt-email" placeholder="john.doe@example.com" aria-label="john.doe@example.com" aria-describedby="buddy_email2" name="buddy_email" />
                                            <small class="form-text text-muted"> You can use letters, numbers & periods </small>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="buddy_reference">Buddy Reference</label>
                                            <input type="text" id="buddy_reference" class="form-control dt-refrence" aria-describedby="buddy_reference2" name="buddy_reference" />
                                            <small class="form-text text-muted"> Reference </small>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="buddy_village">Buddy Village</label>
                                            <input type="text" id="buddy_village" class="form-control dt-village" aria-describedby="buddy_village2" name="buddy_village" />
                                            <small class="form-text text-muted"> Village </small>
                                        </div>
                                        <input type="text" value="{{Auth::user()->name}}" name="usernamesave" hidden>
                                        <button type="submit" class="btn btn-primary mr-1 data-submit">Submit</button>
                                        <button type="reset" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Modal to add new user Ends-->

                        <!-- Modal to update new user starts-->
                        <div class="modal modal-slide-in update_user_modal fade" id="modals-slide-in">
                            <div class="modal-dialog">
                                <form class="add-new-user modal-content pt-0" >
                                    {{csrf_field()}}
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                                    <div class="modal-header mb-1">
                                        <h5 class="modal-title" id="exampleModalLabel">New Buddy</h5>
                                    </div>
                                    <div class="modal-body flex-grow-1">
                                        <div class="form-group">
                                            <label class="form-label" for="ubuddy_name">Buddy Name</label>
                                            <input type="text" class="form-control dt-full-name" id="ubuddy_name" placeholder="John Doe" name="ubuddy_name" aria-label="John Doe" aria-describedby="ubuddy_name2" required/>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="ubuddy_contact">Buddy Contact</label>
                                            <input type="text" class="form-control dt-Contact" id="ubuddy_contact" placeholder="John Doe" name="ubuddy_contact" aria-label="John Doe" aria-describedby="ubuddy_contact2" required/>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="ubuddy_email">Buddy Email</label>
                                            <input type="email" id="ubuddy_email" class="form-control dt-email" placeholder="john.doe@example.com" aria-label="john.doe@example.com" aria-describedby="ubuddy_email2" name="ubuddy_email" required/>
                                            <small class="form-text text-muted"> You can use letters, numbers & periods </small>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="ubuddy_reference">Buddy Reference</label>
                                            <input type="text" id="ubuddy_reference" class="form-control dt-refrence" aria-describedby="ubuddy_reference2" name="ubuddy_reference" required/>
                                            <small class="form-text text-muted"> Reference </small>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="ubuddy_village">Buddy Village</label>
                                            <input type="text" id="ubuddy_village" class="form-control dt-village" aria-describedby="ubuddy_village2" name="ubuddy_village" required/>
                                            <small class="form-text text-muted"> Village </small>
                                        </div>
                                        <input type="text" value="{{Auth::user()->name}}" id="Uusernamesave" name="Uusernamesave" hidden>
                                        <button type="button" class="btn btn-primary mr-1 data-submit update_data_user">Submit</button>
                                        <button type="reset" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Modal to update new user Ends-->
                    </div>
                    <!-- list section end -->
                </section>
                <!-- users list ends -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    @include('layouts/footer')
    <!-- END: Footer-->

    <!-- BEGIN: Page JS-->
    <script src="../../../app-assets/js/scripts/pages/app-userinterface-list.js"></script>
    <!-- END: Page JS-->

    <script>
        $(function(){
        
            $(".dt-buttons").last().addClass("{{Auth::user()->role}}");
            $(".userupdate_new").on("click", function(){
                var $id = $(this).data('id');
                var $userid = 'interfaceupdate/' + ($(this).data('id'));
                // $("#uUserid").val($(this).data('id'));
                $("#ubuddy_name").val($(this).data('buddyname'));
                $("#ubuddy_contact").val($(this).data('buddycontact'));
                $("#ubuddy_email").val($(this).data('buddyemail'));
                $("#ubuddy_reference").val($(this).data('buddyreference'));
                $("#ubuddy_village").val($(this).data('buddyvillage'));
                $(".update_user_modal").modal('show');
                
                $('.update_data_user').on("click", function(){
                    console.log($userid);
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'post',
                        url: $userid,
                        data: { id: $id, buddyname: $("#ubuddy_name").val(), buddycontact: $("#ubuddy_contact").val(), buddyemail: $("#ubuddy_email").val(), buddyreference: $("#ubuddy_reference").val(), buddyvillage: $("#ubuddy_village").val(), usernamesave:$('#Uusernamesave').val()},
                        success: function(data) {
                            if(data['success']){
                                window.location.reload();
                            }
                        }                                   
                    });
                   
                });
            });
            
        });
        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        });
        
    </script>
</body>
<!-- END: Body-->

</html>